import React, {Component} from 'react';

class OrderHistory extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default OrderHistory;