import React, {Component} from 'react';

class OrgHeader extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default OrgHeader;