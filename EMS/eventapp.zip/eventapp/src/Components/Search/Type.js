import React, {Component} from 'react';

class Type extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Type;