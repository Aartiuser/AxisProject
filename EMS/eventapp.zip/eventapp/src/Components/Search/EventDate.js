import React, {Component} from 'react';

class EventDate extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default EventDate;