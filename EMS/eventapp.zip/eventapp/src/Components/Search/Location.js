import React, {Component} from 'react';

class Location extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Location;