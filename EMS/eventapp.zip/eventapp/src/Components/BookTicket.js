import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { MDBCard, MDBCardBody, MDBContainer, MDBInput, MDBModal, MDBModalBody, MDBModalFooter, MDBModalHeader } from 'mdb-react-ui-kit';

function BookTicket(props) {
    const [formData, setFormData] = useState({
        quantity: '',
    });

    const [showForm, setShowForm] = useState(true);
    const [tickets, setTicket] = useState([]);
    const [selectedTicketType, setSelectedTicketType] = useState('');
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const [orderData, setOrderData] = useState(null);
    const [loading, setLoading] = useState(false);

    const urlParams = new URLSearchParams(window.location.search);
    const event = JSON.parse(urlParams.get('event'));

    const Book = (e) => {
        e.preventDefault();

        // Calculate the total price
        const totalPrice = getTicketPrice(selectedTicketType) * formData.quantity;

        // Prepare the order data
        const order = {
            qty: formData.quantity,
            price: totalPrice,
            ticketType: selectedTicketType,
            user: props.email,
        };

        setOrderData(order);
        setShowPaymentModal(true);
    };

    const handleTypechange = (e) => {
        e.preventDefault();
        setSelectedTicketType(e.target.value);
    };

    const handlePayment = async () => {
        try {
            setLoading(true);
            // Send the order data to the backend API
            const response = await axios.post('/api/orders', orderData);
            console.log('Order placed:', response.data);
            setLoading(false);
            setShowPaymentModal(false);
            setShowSuccessModal(true);
        } catch (error) {
            console.error('Error placing order:', error);
            setLoading(false);
            // Handle the error and show an error message to the user
        }
    };

    const handleSuccessModalClose = () => {
        setShowSuccessModal(false);
        // Perform any necessary actions after payment success
        // Update ticket table, etc.
    };

    useEffect(() => {
        const fetchTickets = async () => {
            try {
                const response = await axios.get(`/api/tickets?eventId=${event.id}`);
                setTicket(response.data);
            } catch (error) {
                console.error('Error fetching tickets:', error);
            }
        };

        fetchTickets();
    }, [event.id]);

    const getTicketPrice = (typeId) => {
        const ticket = tickets.find((ticket) => ticket.ticketType.id === typeId);
        return ticket ? ticket.price : null;
    };

    return (
        <div>
            <div className='signup-overlay'>
                {showForm && (
                    <MDBContainer fluid className='d-flex align-items-center justify-content-center '>
                        <div className='mask gradient-custom-3'></div>
                        <MDBCard className='m-5' style={{ maxWidth: '600px' }}>
                            <MDBCardBody className='px-5'>
                                <h2 className='text-uppercase text-center mb-5'>Book Ticket</h2>
                                <div className='form-outline mb-4'>
                                    <label className='form-label' htmlFor='type'>
                                        Type of Ticket
                                    </label>
                                    <select
                                        className='form-control'
                                        id='type'
                                        value={selectedTicketType}
                                        onChange={handleTypechange}
                                    >
                                        <option value=''>Select a ticket type</option>
                                        {tickets.map((ticket) => (
                                            <option key={ticket.ticketType.id} value={ticket.ticketType.id}>
                                                {ticket.ticketType.type}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <MDBInput
                                    wrapperClass='mb-1'
                                    label='Quantity'
                                    size='lg'
                                    id='quantity'
                                    type='text'
                                    value={formData.quantity}
                                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                                />
                                <p>Price : {getTicketPrice(selectedTicketType) ? `$${getTicketPrice(selectedTicketType)}` : 'Loading...'}</p>
                                <button onClick={Book} className='mb-4 w-100 btn btn-dark'>
                                    Book
                                </button>
                            </MDBCardBody>
                        </MDBCard>
                    </MDBContainer>
                )}
            </div>

            <MDBModal isOpen={showPaymentModal} toggle={() => setShowPaymentModal(false)}>
                <MDBModalHeader toggle={() => setShowPaymentModal(false)}>Confirm Payment</MDBModalHeader>
                <MDBModalBody>
                    <p>Total Price: {getTicketPrice(selectedTicketType) * formData.quantity}</p>
                    <p>Quantity: {formData.quantity}</p>
                    <p>Ticket Type: {selectedTicketType}</p>
                </MDBModalBody>
                <MDBModalFooter>
                    <button className='btn btn-secondary' onClick={() => setShowPaymentModal(false)}>
                        Cancel
                    </button>
                    <button className='btn btn-primary' onClick={handlePayment} disabled={loading}>
                        {loading ? 'Processing...' : 'Pay'}
                    </button>
                </MDBModalFooter>
            </MDBModal>

            <MDBModal isOpen={showSuccessModal} toggle={handleSuccessModalClose}>
                <MDBModalHeader toggle={handleSuccessModalClose}>Payment Successful</MDBModalHeader>
                <MDBModalBody>
                    <p>Total Price: {getTicketPrice(selectedTicketType) * formData.quantity}</p>
                    <p>Quantity: {formData.quantity}</p>
                    <p>Ticket Type: {selectedTicketType}</p>
                </MDBModalBody>
                <MDBModalFooter>
                    <button className='btn btn-primary' onClick={handleSuccessModalClose}>
                        OK
                    </button>
                </MDBModalFooter>
            </MDBModal>
        </div>
    );
}

export default BookTicket;
