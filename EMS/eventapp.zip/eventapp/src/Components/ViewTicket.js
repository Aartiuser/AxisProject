import React, {Component} from 'react';

class ViewTicket extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default ViewTicket;