function TicketType(){

}
export default TicketType;