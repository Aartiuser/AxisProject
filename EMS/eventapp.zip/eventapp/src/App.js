import './App.css';
import {Route, Router, Switch} from "react-router-dom";
import Home from "./Components/Home";
import Signup from "./Components/Signup";
import Signin  from "./Components/Signin";
import CreateEvent from "./Components/CreateEvent";
import BookTicket from "./Components/BookTicket";
import {useState} from "react";
import AttendeeHeader from "./Components/AttendeeHeader";
import OrgHeader from "./Components/OrgHeader";
import CreateTicket from "./Components/CreateTicket";
import EventDate from "./Components/Search/EventDate";
import Location from "./Components/Search/Location";
import TicketSales from "./Components/TicketSales";
import Type from "./Components/Search/Type";
import TicketType from "./Components/TicketType";
import UpdateEvent from "./Components/UpdateEvent";
import Analytics from"./Components/Analytics";
import OrderHistory from "./Components/OrderHistory";


function App() {
    const [userRole,setUserRole]=useState(localStorage.getItem('userRole')||'default');
    const [email,setemail]=useState(localStorage.getItem('email')||'default');
    const[event,setevent]=useState(localStorage.getItem('event')||'default');
    const renderHeader=()=>{
        if(UserRole==='Organizer')
            return <OrgHeader setemail={setemail}/>
        else if(UserRole==='Attendee')
            return <AttendeeHeader/>
        else
            return <Home/>
    }
  return (
    <div className="Container">
        <Router>
          {renderHeader()}
          <div className="Container">
            <Switch>
              <Route path="/" exact component={Home}></Route>
              <Route path="/register" exact component={Signup}></Route>
              <Route path="/login" render{()=>(<Signin setUserRole={setUserRole} setemail={setemail}/>)}/>
              <Route path="/UserHome" render{()=>(<CreateEvent email={email}/>)}/>
              <Route path="/Createticket" render{()=>(<CreateTicket email={email}/>)}/>
              <Route path="/update" render{()=>(<UpdateEvent email={email}/>)}/>
              <Route path="/date" exact component={EventDate}></Route>
              <Route path="/location" exact component={Location}></Route>
              <Route path="/type" exact component={Type}></Route>
              <Route path="/Viewtickets" render{()=>(<ViewTickets email={email}/>)}/>
             <Route path="/Viewticketsales" render{()=>(<TicketSales email={email}/>)}/>
             <Route path="/createtype" exact component={TicketType}></Route>
             <Route path="/BookTicket"  render={()=>(<BookTicket email={email} setevent={setevent}/>)}/>
             <Route path="/Analytics" render={()=>(<Analytics email={email}/>)}/>
             <Route path="/OrderHistory" render={()=>(<OrderHistory email={email}/>)}/>

            </Switch>
          </div>
            <Footer/>
        </Router>
    </div>
  );
}

export default App;
